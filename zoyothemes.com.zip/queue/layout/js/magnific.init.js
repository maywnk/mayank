//Cta Video
$('.map-popup-view').magnificPopup({
    disableOn: 375,
    type: 'iframe',
    mainClass: 'mfp-fade',
    removalDelay: 160,
    preloader: false,
    fixedContentPos: false,
});